// netlify/functions/create-checkout-session.js
//
// Crée une session Stripe Checkout à partir du panier envoyé par le front-end.
// Nécessite la variable d'environnement STRIPE_SECRET_KEY sur Netlify.

const Stripe = require("stripe");

// Catalogue côté serveur : ne JAMAIS faire confiance aux prix envoyés par le
// navigateur. On ne reçoit que l'id + la quantité, et on va chercher le prix ici.
const PRODUCTS = {
  "cl-01": { name: "Nettoyant Doux Verveine", price: 18 },
  "se-01": { name: "Sérum Niacinamide", price: 24 },
  "se-02": { name: "Sérum Acide Hyaluronique", price: 26 },
  "hy-01": { name: "Crème Céramides", price: 28 },
  "so-01": { name: "Fluide SPF50 Invisible", price: 22 },
  "se-03": { name: "Sérum Vitamine C", price: 30 },
  "tr-01": { name: "Exfoliant AHA/BHA", price: 25 },
  "tr-02": { name: "Contour des Yeux Caféine", price: 21 },
};

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }

  if (!process.env.STRIPE_SECRET_KEY) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "STRIPE_SECRET_KEY manquante dans les variables d'environnement Netlify." }),
    };
  }

  try {
    const stripe = Stripe(process.env.STRIPE_SECRET_KEY);
    const { items } = JSON.parse(event.body || "{}");

    if (!Array.isArray(items) || items.length === 0) {
      return { statusCode: 400, body: JSON.stringify({ error: "Panier vide." }) };
    }

    const line_items = items.map(({ id, qty }) => {
      const product = PRODUCTS[id];
      if (!product) throw new Error(`Produit inconnu: ${id}`);
      const quantity = Math.max(1, Math.min(20, parseInt(qty, 10) || 1));
      return {
        price_data: {
          currency: "eur",
          product_data: { name: product.name },
          unit_amount: Math.round(product.price * 100),
        },
        quantity,
      };
    });

    const siteUrl = process.env.URL || "http://localhost:8888";

    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      line_items,
      success_url: `${siteUrl}/success.html`,
      cancel_url: `${siteUrl}/`,
      shipping_address_collection: {
        allowed_countries: ["FR", "BE", "CH", "LU", "MC"],
      },
    });

    return { statusCode: 200, body: JSON.stringify({ url: session.url }) };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
};
