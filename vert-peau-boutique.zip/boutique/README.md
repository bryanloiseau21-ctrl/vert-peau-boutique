# Vert · Peau — Boutique skincare

Boutique en ligne avec panier fonctionnel et paiement réel via **Stripe Checkout**,
prête à déployer sur **Netlify**.

## Contenu du projet

```
boutique/
├── index.html                              → la boutique (produits, panier)
├── success.html                             → page affichée après paiement
├── netlify.toml                             → config Netlify
├── package.json                             → dépendance "stripe"
└── netlify/functions/
    └── create-checkout-session.js           → crée le paiement côté serveur
```

Le prix de chaque produit est vérifié **côté serveur** (dans la fonction), jamais
fait confiance à ce qu'envoie le navigateur — c'est important pour la sécurité.

---

## Étape 1 — Créer un compte Stripe

1. Va sur [stripe.com](https://stripe.com) et crée un compte (gratuit).
2. Reste en **mode test** pour l'instant (interrupteur en haut à droite du dashboard).
3. Va dans **Développeurs → Clés API** et copie la **clé secrète** (elle commence par `sk_test_...`).

## Étape 2 — Mettre le projet sur GitHub

Comme pour Loomwork :
1. Crée un nouveau repo GitHub (ex : `vert-peau-boutique`).
2. Mets-y tous les fichiers de ce dossier.

```bash
cd boutique
git init
git add .
git commit -m "Boutique skincare avec Stripe"
git branch -M main
git remote add origin https://github.com/TON-USER/vert-peau-boutique.git
git push -u origin main
```

## Étape 3 — Déployer sur Netlify

1. Sur [app.netlify.com](https://app.netlify.com), clique **Add new site → Import an existing project**.
2. Choisis ton repo GitHub.
3. Build settings : laisse tout vide (pas de build command), **Publish directory = `.`**.
4. Clique **Deploy**.

## Étape 4 — Ajouter la clé Stripe sur Netlify

C'est l'étape la plus importante — sans elle, le paiement ne marchera pas :

1. Dans ton site Netlify → **Site configuration → Environment variables**.
2. Ajoute une variable :
   - **Key** : `STRIPE_SECRET_KEY`
   - **Value** : ta clé `sk_test_...` copiée à l'étape 1
3. Redéploie le site (**Deploys → Trigger deploy**) pour que la variable soit prise en compte.

## Étape 5 — Tester

1. Ouvre ton site, ajoute un produit au panier, clique **Payer avec Stripe**.
2. Tu es redirigé vers une vraie page de paiement Stripe.
3. Utilise une carte de test : `4242 4242 4242 4242`, n'importe quelle date future, n'importe quel CVC.
4. Le paiement passe → tu es redirigé vers `success.html`.
5. Dans ton dashboard Stripe (mode test), tu verras le paiement apparaître.

## Étape 6 — Passer en vrai (mode live)

Quand tu es prêt à encaisser de vrais paiements :
1. Active ton compte Stripe (infos entreprise/banque demandées par Stripe).
2. Bascule le dashboard en **mode live**, récupère la nouvelle clé `sk_live_...`.
3. Remplace la variable `STRIPE_SECRET_KEY` sur Netlify par cette clé live.
4. Redéploie.

---

## Limites à connaître

- **Pas de gestion de stock** : si tu veux suivre les stocks, il faudra une vraie base
  de données (ça peut se rajouter plus tard).
- **Pas d'emails automatiques de confirmation vendeur** : Stripe envoie un reçu à l'acheteur,
  mais toi tu verras les commandes dans ton dashboard Stripe (ou on peut brancher un webhook
  plus tard pour t'envoyer un email/Slack à chaque vente).
- **Produits en dur dans le code** : pour changer un prix ou ajouter un produit, il faut
  éditer `index.html` ET `netlify/functions/create-checkout-session.js` (les deux, pour
  que les prix restent synchronisés).

Si tu veux, je peux aussi t'aider à brancher un webhook Stripe pour être notifié à chaque
vente, ou à connecter un vrai fournisseur/dropshipping pour les produits.
